const DB_NAME = "highly-lucrative-db";
const DB_VERSION = 1;
const DEFAULTS = { openingBalance: 26155, monthlyBudget: 10000 };
let db;
let state = { settings: {...DEFAULTS}, records: [], goals: [] };
let analysisDate = new Date();
let calendarDate = new Date();
let selectedDay = dateKey(new Date());

const $ = (id) => document.getElementById(id);
const yen = (n) => "¥" + Number(n || 0).toLocaleString("ja-JP");
const dateKey = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;
const monthRecords = (d) => state.records.filter(r => r.date.startsWith(monthKey(d)));
const sum = (arr, type) => arr.filter(r => r.type === type).reduce((a,r) => a+r.amount,0);
function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{
      const d=req.result;
      if(!d.objectStoreNames.contains("records")) d.createObjectStore("records",{keyPath:"id",autoIncrement:true});
      if(!d.objectStoreNames.contains("goals")) d.createObjectStore("goals",{keyPath:"id",autoIncrement:true});
      if(!d.objectStoreNames.contains("settings")) d.createObjectStore("settings",{keyPath:"key"});
    };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error);
  });
}
function tx(store,mode="readonly"){return db.transaction(store,mode).objectStore(store)}
function getAll(store){return new Promise((resolve,reject)=>{const r=tx(store).getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function getSetting(key){return new Promise((resolve,reject)=>{const r=tx("settings").get(key);r.onsuccess=()=>resolve(r.result?.value);r.onerror=()=>reject(r.error)})}
function put(store,value){return new Promise((resolve,reject)=>{const r=tx(store,"readwrite").put(value);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function add(store,value){return new Promise((resolve,reject)=>{const r=tx(store,"readwrite").add(value);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function remove(store,id){return new Promise((resolve,reject)=>{const r=tx(store,"readwrite").delete(id);r.onsuccess=resolve;r.onerror=()=>reject(r.error)})}
async function load(){
  state.records=await getAll("records");
  state.goals=await getAll("goals");
  state.settings.openingBalance=(await getSetting("openingBalance")) ?? DEFAULTS.openingBalance;
  state.settings.monthlyBudget=(await getSetting("monthlyBudget")) ?? DEFAULTS.monthlyBudget;
  render();
}
function balance(){return state.settings.openingBalance+sum(state.records,"income")-sum(state.records,"expense")}
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),2600)}
function iconFor(category){return ({食費:"🍽",飲み物:"☕",趣味:"✦",交通費:"🚃",買い物:"◇",学用品:"✎",その他:"•"})[category]||"•"}
function recordRow(r,withDelete=true){
  const div=document.createElement("div");div.className="entry-row";
  const title=r.note||r.category;
  div.innerHTML=`<div class="entry-icon">${iconFor(r.category)}</div><div class="entry-main"><strong></strong><small>${r.date} · ${r.category}</small></div><span class="entry-amount ${r.type==="income"?"positive":"negative"}">${r.type==="income"?"+":"−"}${yen(r.amount)}</span>${withDelete?'<button class="delete-button" aria-label="削除">×</button>':""}`;
  div.querySelector(".entry-main strong").textContent=title;
  if(withDelete)div.querySelector("button").addEventListener("click",async()=>{if(confirm("この記録を削除しますか？")){await remove("records",r.id);await load();toast("記録を削除しました") }});
  return div;
}
function renderHome(){
  $("balance").textContent=yen(balance());
  const m=monthRecords(new Date());
  $("month-income").textContent="+"+yen(sum(m,"income"));
  $("month-expense").textContent="−"+yen(sum(m,"expense"));
  const spent=sum(m,"expense"),budget=Number(state.settings.monthlyBudget)||0,pct=budget?Math.round(spent/budget*100):0;
  $("budget-caption").textContent=`支出 ${yen(spent)} / ${yen(budget)}`;
  $("budget-percent").textContent=pct+"%";
  $("budget-progress").style.width=Math.min(pct,100)+"%";
  $("budget-message").textContent=budget===0?"設定から月の予算を入力できます。":pct>=100?"予算を超えています。支出を確認しましょう。":pct>=90?"予算の90%以上を使用しています。":pct>=70?"予算の70%以上を使用しています。":"予算内でいいペースです。";
  const list=$("recent-list");list.replaceChildren();
  const recent=[...state.records].sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id).slice(0,5);
  if(!recent.length)list.innerHTML='<p class="empty">まだ記録がありません。</p>';else recent.forEach(r=>list.append(recordRow(r,false)));
}
function renderRecords(){
  const list=$("all-records");list.replaceChildren();
  const rows=[...state.records].sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id);
  if(!rows.length)list.innerHTML='<p class="empty">記録はまだありません。</p>';else rows.forEach(r=>list.append(recordRow(r)));
}
function renderAnalysis(){
  const d=analysisDate,m=monthRecords(d),inc=sum(m,"income"),exp=sum(m,"expense");
  $("month-label").textContent=`${d.getFullYear()}年${d.getMonth()+1}月`;
  $("analysis-income").textContent=yen(inc);$("analysis-expense").textContent=yen(exp);
  const max=Math.max(inc,exp,1);
  $("monthly-chart").innerHTML=`<div class="bar-column"><strong class="bar-value">${yen(inc)}</strong><div class="bar-track"><div class="bar-fill" style="height:${inc/max*100}%"></div></div><span class="bar-label">収入</span></div><div class="bar-column"><strong class="bar-value">${yen(exp)}</strong><div class="bar-track"><div class="bar-fill expense" style="height:${exp/max*100}%"></div></div><span class="bar-label">支出</span></div>`;
  const cats={};m.filter(r=>r.type==="expense").forEach(r=>cats[r.category]=(cats[r.category]||0)+r.amount);
  const entries=Object.entries(cats).sort((a,b)=>b[1]-a[1]);const box=$("category-chart");box.replaceChildren();
  if(!entries.length){box.innerHTML='<p class="empty">支出を記録すると表示されます。</p>';return}
  entries.forEach(([name,value])=>{const row=document.createElement("div");row.className="cat-row";row.innerHTML=`<div class="cat-meta"><strong></strong><span>${yen(value)}</span></div><div class="cat-track"><span style="width:${value/exp*100}%"></span></div>`;row.querySelector("strong").textContent=name;box.append(row)});
}
function renderCalendar(){
  const y=calendarDate.getFullYear(),m=calendarDate.getMonth();$("calendar-label").textContent=`${y}年${m+1}月`;
  const first=new Date(y,m,1),start=new Date(y,m,1-first.getDay()),grid=$("calendar-grid");grid.replaceChildren();
  const today=dateKey(new Date());
  for(let i=0;i<42;i++){
    const d=new Date(start);d.setDate(start.getDate()+i);const key=dateKey(d);
    const spent=sum(state.records.filter(r=>r.date===key),"expense");
    const b=document.createElement("button");b.className="day-cell"+(d.getMonth()!==m?" other":"")+(key===selectedDay?" selected":"")+(key===today?" today":"");
    b.innerHTML=`<span class="day-number">${d.getDate()}</span>${spent?`<span class="day-spend">${yen(spent)}</span>`:""} `;
    b.addEventListener("click",()=>{selectedDay=key;renderCalendar()});grid.append(b);
  }
  $("selected-date-title").textContent=selectedDay.replaceAll("-","/");
  const detail=$("day-details");detail.replaceChildren();const dayRows=state.records.filter(r=>r.date===selectedDay).sort((a,b)=>a.id-b.id);
  if(!dayRows.length)detail.innerHTML='<p class="empty">この日の記録はありません。</p>';else dayRows.forEach(r=>detail.append(recordRow(r,false)));
}
function renderGoals(){
  const list=$("goals-list");list.replaceChildren();
  if(!state.goals.length){list.innerHTML='<article class="panel"><p class="empty">貯金目標はまだありません。</p></article>';return}
  state.goals.forEach(g=>{
    const pct=Math.min(100,Math.round(g.saved/g.target*100));const card=document.createElement("article");card.className="panel goal-card";
    card.innerHTML=`<div class="goal-card-top"><div><strong></strong><br><small>目標 ${yen(g.target)}</small></div><b>${pct}%</b></div><div class="progress"><span style="width:${pct}%"></span></div><div class="goal-numbers"><span>貯金済み ${yen(g.saved)}</span><span>あと ${yen(Math.max(0,g.target-g.saved))}</span></div><div class="goal-actions"><button class="secondary-button add-savings">貯金を追加</button><button class="secondary-button delete-goal">削除</button></div>`;
    card.querySelector("strong").textContent=g.name;
    card.querySelector(".add-savings").addEventListener("click",async()=>{const n=Number(prompt("追加する金額（円）"));if(!Number.isSafeInteger(n)||n<=0)return;g.saved+=n;await put("goals",g);await load();toast("貯金額を更新しました")});
    card.querySelector(".delete-goal").addEventListener("click",async()=>{if(confirm("この目標を削除しますか？")){await remove("goals",g.id);await load()}});
    list.append(card);
  });
}
function render(){renderHome();renderRecords();renderAnalysis();renderCalendar();renderGoals();$("opening-balance").value=state.settings.openingBalance;$("monthly-budget").value=state.settings.monthlyBudget}
function checkBudget(previousSpent,currentSpent){
  const budget=Number(state.settings.monthlyBudget)||0;if(!budget)return;
  const thresholds=[{n:70,msg:"今月の予算の70%に達しました。"},{n:90,msg:"今月の予算の90%に達しました。"},{n:100,msg:"今月の予算を超えました。"}];
  for(const t of thresholds){if(previousSpent<budget*t.n/100&&currentSpent>=budget*t.n/100){toast(t.msg);if("Notification"in window&&Notification.permission==="granted")new Notification("highly lucrative",{body:t.msg});}}
}
function showView(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===name+"-view"));
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.go===name));
  if(name==="analysis")renderAnalysis();if(name==="calendar")renderCalendar();
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.go)));
$("record-date").value=dateKey(new Date());
$("record-form").addEventListener("submit",async e=>{
  e.preventDefault();const amount=Number($("record-amount").value),type=document.querySelector('input[name="type"]:checked').value,date=$("record-date").value;
  if(!Number.isSafeInteger(amount)||amount<=0||!date){toast("金額と日付を確認してください");return}
  if(type==="expense"&&amount>balance()){toast("残高が足りません");return}
  const oldSpent=sum(monthRecords(new Date(date)), "expense");
  await add("records",{amount,type,category:$("record-category").value,date,note:$("record-note").value.trim()});
  if(type==="expense"){const newMonth=monthRecords(new Date(date));checkBudget(oldSpent,sum(newMonth,"expense"))}
  e.target.reset();$("record-date").value=dateKey(new Date());document.querySelector('input[name="type"][value="expense"]').checked=true;await load();showView("home");toast("記録を保存しました");
});
$("goal-form").addEventListener("submit",async e=>{
  e.preventDefault();const name=$("goal-name").value.trim(),target=Number($("goal-target").value),saved=Number($("goal-saved").value);
  if(!name||!Number.isSafeInteger(target)||target<=0||!Number.isSafeInteger(saved)||saved<0){toast("入力内容を確認してください");return}
  await add("goals",{name,target,saved});e.target.reset();$("goal-saved").value="0";await load();toast("貯金目標を追加しました");
});
$("prev-month").addEventListener("click",()=>{analysisDate.setMonth(analysisDate.getMonth()-1);renderAnalysis()});
$("next-month").addEventListener("click",()=>{analysisDate.setMonth(analysisDate.getMonth()+1);renderAnalysis()});
$("cal-prev").addEventListener("click",()=>{calendarDate.setMonth(calendarDate.getMonth()-1);renderCalendar()});
$("cal-next").addEventListener("click",()=>{calendarDate.setMonth(calendarDate.getMonth()+1);renderCalendar()});
$("save-settings").addEventListener("click",async()=>{
  const opening=Number($("opening-balance").value),budget=Number($("monthly-budget").value);
  if(!Number.isSafeInteger(opening)||opening<0||!Number.isSafeInteger(budget)||budget<0){toast("0以上の整数を入力してください");return}
  state.settings.openingBalance=opening;state.settings.monthlyBudget=budget;
  await put("settings",{key:"openingBalance",value:opening});await put("settings",{key:"monthlyBudget",value:budget});render();toast("設定を保存しました");
});
$("enable-notifications").addEventListener("click",async()=>{
  if(!("Notification"in window)){$("notification-status").textContent="このブラウザは通知に対応していません。";return}
  const result=await Notification.requestPermission();$("notification-status").textContent=result==="granted"?"ブラウザ通知が有効になりました。":"通知は許可されませんでした。";
});
$("export-data").addEventListener("click",()=>{
  const data={version:1,settings:state.settings,records:state.records,goals:state.goals};
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download=`highly-lucrative-backup-${dateKey(new Date())}.json`;a.click();URL.revokeObjectURL(url);
});
$("import-data").addEventListener("change",async e=>{
  const file=e.target.files[0];if(!file)return;
  try{
    const data=JSON.parse(await file.text());if(!data||!Array.isArray(data.records)||!Array.isArray(data.goals)||!data.settings)throw Error("invalid");
    if(!confirm("現在のデータをバックアップの内容に置き換えます。よろしいですか？"))return;
    const clearStore=(name)=>new Promise((resolve,reject)=>{const r=tx(name,"readwrite").clear();r.onsuccess=resolve;r.onerror=()=>reject(r.error)});
    await Promise.all(["records","goals","settings"].map(clearStore));
    for(const r of data.records)await add("records",r);
    for(const g of data.goals)await add("goals",g);
    await put("settings",{key:"openingBalance",value:Number(data.settings.openingBalance)||0});
    await put("settings",{key:"monthlyBudget",value:Number(data.settings.monthlyBudget)||0});
    await load();toast("バックアップを読み込みました");
  }catch(err){toast("バックアップを読み込めませんでした")}
  e.target.value="";
});
async function init(){
  try{db=await openDB();await load();if("serviceWorker"in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});}
  catch(e){document.body.innerHTML='<main style="padding:30px;font-family:sans-serif"><h2>データベースを開けませんでした</h2><p>ブラウザのプライベートモードを解除するか、別のブラウザで開いてください。</p></main>';}
}
init();
